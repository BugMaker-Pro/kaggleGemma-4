#!/usr/bin/env bash
set -e
patch="$(cat tmp/router_robust_threshold.patch)"
"/c/Users/Administrator/.vscode/extensions/openai.chatgpt-26.1021.22027-win32-x64/bin/windows-x86_64/codex.exe" --codex-run-as-apply-patch "$patch"