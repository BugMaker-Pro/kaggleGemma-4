﻿from pathlib import Path
p=Path('paper/main.md');s=p.read_text(encoding='utf-8')
s=s.replace('# Paper draft (v12: scoped claims and novelty review)', '# Paper draft (v13: topology controls and representation interaction)')
a=s.index('## Abstract');b=s.index('## 1. Introduction',a)
s=s[:a]+'''## Abstract

File-level localization can hide missed definitions, but graph utility also depends on the comparison. We audit patch-derived targets and separate candidate coverage, shortlist selection, and topology controls. On 290 scorable SWE-bench Lite tasks, one ranking recovers **62.4%** of gold files but **27.5%** of gold symbols at ten slots. Graph reranking gains **2.2 points** on 2,232 tasks. A follow-up holds candidate pools fixed and compares real edges with degree- and file-constrained rewiring under metadata, body, and dense rankings. Real graphs outperform rewiring by **2.14, 0.90, and 1.76 points**, respectively; metadata and dense contrasts survive repository-level testing with Holm correction. Yet gains over the original rankings are **2.19, −0.01, and 0.64 points**: topology signal and useful intervention differ. Representation interactions do not survive correction. A learned ranker plus dense scores reaches **44.7%** symbol and **72.7%** file recall. We release targets, graph controls, rankings, and audits. Results characterize static, fixed-slot retrieval, not general graph-guided agent effectiveness.

---

'''+s[b:]
s=s.replace('and index-content controls separating representation effects from graph effects.', 'and constrained topology controls across three input representations. These distinguish a graph carrying signal from a reranking policy improving retrieval.')
s=s.replace('fixed-slot target displacement, candidate-pool ceilings, index-body controls, and an independently audited patch-derived answer key.', 'fixed-slot target displacement, candidate ceilings, degree/file-matched topology controls across retrieval representations, and an independently audited answer key.')
a=s.index('**Resolution states.**');b=s.index('**The arms.**',a)
s=s[:a]+'''**Resolution.** Calls are classified as local, imported, unique-name, suffix-matched, external, ambiguous, or unresolved. On one django snapshot, **46%** resolve to a definite in-repository target. This is a resolution diagnostic, not measured edge precision.

'''+s[b:]
a=s.index('**Subsample stability.**');b=s.index('**Reproducibility.**',a)
s=s[:a]+'''**Topology versus intervention.** A follow-up fixes the original candidate pool and compares metadata, body-inclusive BM25, and frozen dense orders. We retain five seeds, promote one-hop neighbours in the remaining slots, and compare real edges with same-file promotion and constrained rewiring. This matches full-scale reranking; historical Lite arms could move seeds. Body scores use whole-repository corpus statistics. Dense retains saved score order; historical rounded-score tie handling changes one task's base recall, without changing the inference.

Each randomized graph preserves every candidate's within-file and cross-file degree; a stricter variant also preserves its degree to each partner file. Five fixed random seeds use 20 attempted swaps per edge, with invariants checked. Random outcomes are averaged within task. Five planned contrasts—real minus rewired under each representation, and two interactions against metadata—use exhaustive repository sign flips and Holm correction; intervals use 10,000 repository-cluster resamples. Protocol and input hashes were fixed before new outcome inspection.

*Table 8 — follow-up symbol recall@10 on 2,232 tasks; p tests real minus rewired with Holm correction*

| base representation | base | real | same-file | rewired | file-pair rewired | p |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| metadata | 0.2479 | 0.2698 | 0.2534 | 0.2484 | 0.2612 | 0.0137 |
| body | 0.3171 | 0.3170 | 0.3295 | 0.3080 | 0.3128 | 0.1787 |
| dense | 0.3659 | 0.3723 | 0.3645 | 0.3547 | 0.3658 | 0.0049 |

Real-minus-rewired effects are +2.14 (CI 1.34–2.66), +0.90 (0.01–1.58), and +1.76 (1.04–2.82) points. The body and dense interactions are −1.24 and −0.38 points (Holm p = 0.126 and 0.598): neither establishes attenuation. Real-minus-base effects are +2.19, −0.01, and +0.64 points; the dense secondary repository test has p = 0.069. Thus rejecting a randomized topology does not establish a useful improvement over dense retrieval.

The primary null replaces 54.2% of edges on average; 28 graphs accept no swap. The stricter null replaces 19.0%, with 273 immobile graphs: smaller residual differences need that qualification. Same-file promotion is a coarse, unmatched-density control; real-versus-file effects are not significant under repository tests. All controls and mobility subsets are released.

'''+s[b:]
s=s.replace('plus commands and fold definitions in `docs/reproduction.md`.', 'with protocols in `docs/reproduction.md` and `docs/graph-control-protocol.md`.')
a=s.index('## 6. Discussion');b=s.index('## 7. Limitations',a)
s=s[:a]+'''## 6. Discussion

Reranking changes selection inside a pool; expansion can add targets but displace existing hits. On Lite, the 200-candidate oracle reaches 0.600, rising to 0.630 with neighbours. These are candidate-set ceilings, not universal graph limits. Among 80 tasks missed by a 500-candidate pool, only 12 contain our detected exact cues. Absence of these cues does not imply absence of semantic evidence.

The follow-up separates **structural signal from intervention value**. Real topology beats a degree/file-constrained null under metadata and dense ranking, yet its fixed promotion rule adds little over body or dense retrieval. Stronger inputs also leave less unfilled oracle headroom; the interaction does not isolate an information-substitution mechanism. The results support topology-sensitive diagnostics, not a claim that better text makes graphs redundant.

---

'''+s[b:]
s=s.replace('Task-level intervals and sign tests do not fully model repository dependence or multiple comparisons.', 'Historical task-level inference omits repository dependence; follow-up tests address clustering but assume symmetric repository effects under the null. Constrained swaps are not proven uniformly sampled or mixed.')
a=s.index('## 8. Conclusion');b=s.index('## References',a)
s=s[:a]+'''## 8. Conclusion

Fixed-slot retrieval can credit files while missing edited definitions. Our audit diagnoses candidate coverage and displacement. Matched topology controls reveal signal under metadata and dense rankings, but signal does not guarantee improvement from a simple reranking policy. Representation interactions remain inconclusive after correction. The contribution is a reproducible diagnosis with explicit controls and limits; learned feature/dense fusion reaches 44.7% symbol and 72.7% file recall.

---

'''+s[b:]
# Keep the historical conditional subset analysis recorded outside the submitted body.
s=s.replace('## Claim → evidence', '## Claim → evidence\n\nHistorical subsample analysis (moved to supplementary records): 88% detection at n=100 for the ranker; 39% at n=290 and 87% at n=800 for graph reranking. `data/power_analysis.json` remains audited. The new Table 8 reports topology controls instead.\n\nNew result: true-minus-rewired effects 2.14/0.90/1.76 points; Holm p 0.0137/0.1787/0.0049. Follow-up interaction tests are inconclusive. See `docs/graph-control-results.md` and `tools/audit_graph_controls.py`.')
p.write_text(s,encoding='utf-8',newline='\n')
# Table order changed after compressing the unnumbered resolution table.
p=Path('tools/make_kaggle_full.py');s=p.read_text(encoding='utf-8');a=s.index('LEGEND = {');b=s.index('\n\n\ndef render',a)
s=s[:a]+'''LEGEND = {
    1: "granularity: recall@1 · recall@5 · recall@10",
    2: "arm: r@1 · r@5 · r@10 · file r@10 · Δ r@10, 95% CI, p",
    4: "ranking: r@10 · Δ vs BM25, 95% CI · wins/losses · p",
    5: "ranking: symbol recall@10 · file recall@10",
    6: "each row: n · BM25 · ranker, for 290 tasks then 2,232",
    7: "reading: 290 tasks · 2,232 tasks",
    8: "representation: base · real · same-file · rewired · file-pair rewired · Holm p",
}'''+s[b:]
s=s.replace('if table == 1:  # resolution states: state -> meaning\n        return f"- **{row[0]}** — {row[1]}"\n    if table == 4:', 'if table == 3:')
p.write_text(s,encoding='utf-8',newline='\n')
