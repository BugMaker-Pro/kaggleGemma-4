﻿import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path('.').resolve()))
from experiments.cached_graph import CachedBuilder,cached_body_scores
from experiments.buildgraph import build_graph,read_snapshot,to_json
from experiments.snapindex import SnapshotIndex
from experiments.graph_controls import body_documents,bm25_subset
features={}
for line in Path('data/features_full.jsonl').open(encoding='utf-8'):
 row=json.loads(line)
 if row['repo'] in ['astropy/astropy','django/django','sympy/sympy'] and row['repo'] not in features:
  features[row['repo']]=row
metadata={json.loads(line)['instance_id']:json.loads(line) for line in Path('data/swebench_full.jsonl').open(encoding='utf-8')}
builder=CachedBuilder()
for repo,feature in features.items():
 task=metadata[feature['instance_id']]; files=read_snapshot(SnapshotIndex('data/repos').path_for(task))
 started=time.perf_counter(); expected,_=build_graph(files); original_seconds=time.perf_counter()-started
 started=time.perf_counter(); actual,counts,stats=builder.build(files,repo); cold=time.perf_counter()-started
 assert to_json(expected)==to_json(actual),(repo,'graph mismatch')
 a=bm25_subset(body_documents(expected.nodes,files),task['problem_statement'],feature['ids'])
 b=cached_body_scores(counts,task['problem_statement'],feature['ids']);assert a==b,(repo,'scores differ')
 started=time.perf_counter(); warm,_,stats=builder.build(files,repo);warm_seconds=time.perf_counter()-started
 assert to_json(warm)==to_json(actual)
 print(repo,'nodes',len(actual.nodes),'edges',len(actual.edges),'original_s',round(original_seconds,2),'cold_s',round(cold,2),'warm_s',round(warm_seconds,2),'PARITY OK',flush=True)
