﻿from pathlib import Path
import re
p=Path('docs/status.md');s=p.read_text(encoding='utf-8');start=s.index('| **Title**');end=s.index('\n## 状态',start)
s=s[:start]+'''| **Title** | `Beyond File Hits: Candidate Coverage and Graph Utility in Code Localization` |
| **Subtitle** | `A controlled retrieval study of graph reach, shortlist displacement, and index content on SWE-bench Lite and the full test split` |
| **Body** | [paper/kaggle_body_img.md](../paper/kaggle_body_img.md)：2,321 词（仅文字，另含表图内容）、10 个小节、**10 个图片位**；顺序为 `table_resolution` → `table_1` → `fig1` → `table_2` → `table_3` → `table_4` → `table_5` → `table_6` → `table_7` → `table_8` |
| **PDF** | [paper/submission.pdf](../paper/submission.pdf)，5 页；与 Markdown 同源生成，并检查正文与表格一致性 |
| **字数** | 完整文本含标题、副标题和表格，按仓库计数规则 **2,842 词**；限额 3,000，预留 158。图片版文字少不代表字数豁免；线上计数最终核对 |
| **Project Links** | `https://github.com/BugMaker-Pro/kaggleGemma-4` + `https://github.com/BugMaker-Pro/kaggleGemma-4/blob/main/paper/submission.pdf` |

表格图共有 9 张（状态表 + Table 1–8）。另有 Figure 1，共 10 个图片位。新增 Table 5 汇总全量的 BM25、图重排、排序器、dense 和融合结果；旧 Table 5–7 顺延。

备选全文：[paper/kaggle_body_full.md](../paper/kaggle_body_full.md)，2,806 词，表格转列表。`paper/kaggle_body.md` 仅是简短项目介绍，不能代替完整论文提交。

2026-11-01 修订：收窄图效应与粒度结论，纠正等字符预算，补全两折仓库评估，说明 Lite/全量重叠与子采样统计边界，补入 Bellam（2026-10-25）近邻引用。新颖性风险和后续实验见 [novelty-review.md](novelty-review.md)，复现协议见 [reproduction.md](reproduction.md)。这些修改尚未上传或替换线上 Writeup。
''' +s[end:]
s=re.sub(r'- \[x\] 数字审计 `tools/audit_numbers.py`：[^\n]*', '- [x] 数字审计 `tools/audit_numbers.py`：零失败；不再在论文中维护易漂移的固定断言数量',s)
s=s.replace('- [ ] 线上 writeup 修正 Figure 1 错位 + 填 Project Links + 点提交', '- [ ] 线上 Writeup 更新为本轮标题与正文、重新上传 Figure 1 和表格图、填 Project Links 并确认正式提交')
s=s.replace('1.1 次', '1.1 次')
p.write_text(s,encoding='utf-8',newline='\n')
