﻿from pathlib import Path
p=Path('tools/analyse_graph_controls.py');s=p.read_text(encoding='utf-8');s=s.replace('效应与区间单位为百分点；区间为仓库 cluster bootstrap。p 值为穷举仓库符号翻转，Holm 同时校正五项。','效应与区间单位为百分点；区间为仓库 cluster bootstrap 的逐项区间（未作同时覆盖校正）。p 值为穷举仓库符号翻转，Holm 同时校正五项。')
s=s.replace('- 仓库符号翻转需要零假设下效果符号可交换/对称；十二个仓库仍限制泛化与精度。','- 仓库符号翻转需要零假设下效果符号可交换/对称；十二个仓库仍限制泛化与精度。区间未对图随机种子的有限抽样做嵌套重采样；另列五种子的结果范围。')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tools/audit_graph_controls.py');s=p.read_text(encoding='utf-8');s=s.replace('First lexicographically encountered task per repository in the stored','First encountered task per repository in the stored');p.write_text(s,encoding='utf-8',newline='\n')
