﻿from pathlib import Path
p=Path('tools/analyse_graph_controls.py');s=p.read_text(encoding='utf-8');needle="    lines+=['','## 推断边界','',"
addition='''    sensitivity_path=ROOT/'data/graph_controls_tie_sensitivity.json'
    if sensitivity_path.exists():
        sensitivity=json.loads(sensitivity_path.read_text(encoding='utf-8'))
        lines+=['','## Dense 并列规则敏感性（事后审计发现，主协议未变）','',
                f"原协议保留 encoder 保存的候选顺序；历史融合脚本改为按四舍五入分数排序、候选索引打破并列。共有 {sensitivity['changed_order_tasks']} 个任务的完整顺序不同，{sensitivity['changed_top10_membership_tasks']} 个任务的前十成员不同，{sensitivity['changed_seed_membership_tasks']} 个任务的前五成员不同。",
                '', '只有 django__django-11019 的 dense 基线符号 recall 因边界并列而变化（0 对 1/3），因此全量主实验为 0.3659，历史规则为 0.3661。两种规则均完整报告，不替换主实验。',
                '', '| 主要对比（历史并列规则） | 效应，百分点 | Holm p |',
                '| --- | ---: | ---: |']
        for name,stats in sensitivity['full']['primary'].items():
            lines.append(f"| {name} | {100*stats['delta']:+.2f} | {stats['holm_p']:.4f} |")
        lines+=['', '这项敏感性检查没有改变五个主要对比的显著性判断。']
    lines+=['','## 推断边界','','''
assert needle in s;s=s.replace(needle,addition);p.write_text(s,encoding='utf-8',newline='\n')
