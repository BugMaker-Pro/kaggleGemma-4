﻿from pathlib import Path
import re
p=Path('paper/main.md'); s=p.read_text(encoding='utf-8')
def section(start,end,text):
 global s
 a=s.index(start); b=s.index(end,a)
 s=s[:a]+text.strip()+'\n\n---\n\n'+s[b:]
s=s.replace('# Paper draft (v11)','# Paper draft (v12: scoped claims and novelty review)')
s=re.sub(r'> \*\*Draft status\*\*:.*', '> **Draft status**: revised on 2026-11-01. Counts and publication checks are generated from the submission sources; numerical claims are checked by `tools/audit_numbers.py`. Novelty assessment: [docs/novelty-review.md](../docs/novelty-review.md).',s)
s=s.replace('File-Level Is Not Symbol-Level: What Code Graphs Miss and the Issue Already States','Beyond File Hits: Candidate Coverage and Graph Utility in Code Localization')
s=re.sub(r'Subtitle: .*', 'Subtitle: *A controlled retrieval study of graph reach, shortlist displacement, and index content on SWE-bench Lite and the full test split*',s)
section('## Abstract','## 1. Introduction', '''## Abstract

Code-localization systems report file, function, and repair metrics, but these do not isolate where retrieval loses a target. We audit patch-derived symbols and separate candidate coverage, shortlist selection, and scoring granularity. On 290 scorable SWE-bench Lite tasks, one BM25 ranking recovers **62.4%** of gold files but **27.5%** of gold symbols at ten slots. Seven graph variants yield no statistically significant symbol improvement on Lite; extending evaluation to 2,232 tasks reveals a **2.2-point** graph-reranking gain. Expansion is constrained by sparse useful neighbours and displacement of existing hits: its Lite oracle gain over a 200-candidate pool is three points. Index content matters independently: including candidate bodies improves full-scale BM25 symbol recall by **3.8 points**. A repository-held-out ranker reaches **36.1%**, or **44.7%** with a dense score, while file recall reaches **72.7%**. We release the gold audit, rankings, and diagnostic harness. These findings concern static retrieval under a ten-slot budget, not the effectiveness of graph-guided agents in general.''')
section('## 1. Introduction','## 2. Related Work', '''## 1. Introduction

Finding a relevant file leaves an agent with code to inspect. On Lite, the median gold file contains 48 definitions; its 28,950 characters are 16.1 times the touched definition's length. This motivates measuring retrieval below file level, but neither function-level localization nor graph ablation is new [2,3,11].

Our question is narrower: **when a graph changes a fixed-length shortlist, does it recover missing targets or displace targets already retrieved?** We separate three observable quantities: coverage of the candidate pool, selection within that pool, and hits credited at file versus symbol level. The same ten symbol slots recover 62.4% of files and 27.5% of symbols, a 2.3× ratio; this is a property of this ranking and metric, not a universal difficulty multiplier.

For `matplotlib__matplotlib-24970`, every arm reaches `lib/matplotlib/colors.py` within five slots, yet none selects `Colormap.__call__` within ten even though it is in the pool. Conversely, 80 Lite tasks have no gold symbol in a 500-candidate pool: reranking cannot repair that failure.

Our contribution is an audited empirical decomposition: controlled graph interventions with reach and displacement accounting; a scale extension showing which small-sample findings persist; and index-content controls separating representation effects from graph effects. We do not introduce a new ranker or claim that code graphs are generally ineffective.''')
section('## 2. Related Work','## 3. Setup', '''## 2. Related Work

**Localization and repair.** SWE-bench evaluates patches [1]; SWE-agent studies agent interfaces [5]. LocAgent evaluates multiple localization granularities and graph tools [2], while ARISE reports function and line localization alongside repair [3]. Their agent results cannot be compared numerically with our static retrieval recall.

**Closest graph study.** Bellam [11] ablates grep, embedding, and graph tools across small coding agents, stratifies tasks by graph depth, and measures downstream repair. Thus graph utility, lexical cues, and depth-dependent failures are established research questions. Our complementary scope is the retrieval layer: fixed-slot target displacement, candidate-pool ceilings, index-body controls, and an independently audited patch-derived answer key. We do not claim priority for graph ablations.

**Retrieval representations.** CORE-Bench [8], RepoNav [9], and FuseSearch [10] study repository retrieval and navigation. PyCG [4] evaluates call-graph construction; CodexGraph [6] and RepoAtlas [7] expose repository structure to agents. Our graph resolution rate describes one implementation, not the quality of these systems.''')
s=s.replace('**Tasks.** All 300 SWE-bench Lite instances, 12 repositories, dominated by django (114) and sympy (77); 297 distinct base commits as tarballs (2.5 GB). Nothing is executed: the measurement is over source.', '**Tasks.** Lite has 300 instances across 12 Python repositories, dominated by django (114) and sympy (77), with 297 base commits. The full test split has 2,294 tasks; 2,232 are scorable and 62 lack resolvable gold symbols. Lite is contained in this split, so the larger study is a scale extension, not independent replication. We measure source retrieval without executing patches.')
s=s.replace('We record rather than drop the 87 changed lines outside any definition, so hard cases cannot inflate the score.', 'We separately record 87 changed lines outside definitions; symbol recall excludes these lines and the ten empty-gold tasks.')
s=s.replace('**Query and budget.** The issue text as given: no rewrite, no file hints, no LLM preprocessing — the weakest defensible query. Every arm fills exactly 10 slots, so an arm cannot win by retrieving more.', '**Query and budget.** Lexical and graph arms use the issue text without rewriting. We compare ten symbol slots, not equal token or character counts. File recall groups these same ten symbols by file; it is not retrieval of ten distinct files. BM25 starts from 200 candidates; graph expansion and diffusion can search outside that pool. The 500-candidate diagnostic is separate.')
s=s.replace(' — the only arm that can add a symbol BM25 never ranked','')
s=s.replace('**The granularity gap is the headline.**', '**Scoring granularity.**')
s=s.replace('**At ten slots, no graph arm improves symbol-level recall**', '**No graph variant has a statistically significant symbol improvement on Lite at ten slots**')
s=s.replace('**The file costs sixteen times the fix.**','**Source size, not measured agent cost.**')
s=s.replace('A file-level hit buys the agent the search, not the answer.', 'This is a source-length comparison, not a measured token, latency, or repair saving.')
s=s.replace('the eight arms of §4, paired, equal pool and equal character budget','BM25 and seven graph variants, paired at ten symbol slots; candidate access differs')
s=s.replace('**Diffusion is a lateral move; expansion is worse.**','**Displacement can offset reach.**')
s=s.replace('**Reach bounds the arm; the exchange rate eats the bound**','**Reachable targets do not guarantee net gains**')
s=s.replace('diagnostics, ceilings and the ablation grid (n = 290)','candidate coverage and displacement diagnostics (n = 290)')
s=s.replace('One-hop expansion has an arithmetic ceiling:', 'For this graph and seed policy, one-hop reach has a ceiling:')
s=s.replace('so perfect conversion is worth 11.9 points;', 'giving 11.9% macro-averaged reachable-gold recall before accounting for overlap or displacement;')
s=s.replace('Conversion is not the failure — diffusion places', 'Diffusion places')
s=s.replace('**A learned ranker.** Sixteen features — lexical score and rank, body-quote overlap, path and frame matches, four graph statistics, size and shape terms — feed a LightGBM ranker trained on six repositories, tested on the other six, three seeds averaged, nothing tuned on test.', '**A learned ranker.** Sixteen lexical, issue-evidence, graph, and size features feed LightGBM. We sort the 12 repositories, split alternating entries into two groups of six, then train and test in both directions. Each task is evaluated once on unseen repositories; predictions average three seeds. This is repository-held-out two-fold evaluation, not a new ranking algorithm. Hyperparameters are fixed across folds; exploratory method selection limits claims of an untouched test set.')
# Shift existing table numbers before inserting new table 5.
s=re.sub(r'Table ([5-7])',lambda m:'Table '+str(int(m.group(1))+1),s)
a=s.index('**A dense score is complementary.**'); b=s.index('*Table 6',a)
s=s[:a]+'''**Full-scale ranking.** A frozen 33M bge-small-en-v1.5 encoder scores the same 200 candidates. It embeds the issue's first 1,200 characters and each candidate's path, name, and first 800 body characters, using CLS pooling, cosine similarity, and a 512-token cap. Adding this score to the sixteen features gives +8.6 points (418 wins, 83 losses).

*Table 5 — full-scale recall@10 (n = 2,232); all learned predictions are held out by repository*

| ranking | symbol | file |
| --- | ---: | ---: |
| BM25 | 0.248 | 0.564 |
| graph rerank | 0.270 | 0.564 |
| 16-feature ranker | 0.361 | 0.643 |
| dense score alone | 0.366 | 0.693 |
| ranker + dense score | **0.447** | **0.727** |

The file/symbol ratio falls from 2.28× to 1.63×. Dense scoring also reads body text, so this comparison does not isolate pretraining from input representation.

'''+s[b:]
s=s.replace('What the issue *states* is the signal; the graph is not.', 'Explicit issue evidence predicts larger gains; Table 7 also shows a positive contribution from graph features.')
s=s.replace('**The same claims on 2,232 tasks.** Table 7 repeats them on the full split — 2,174 snapshots, same code, same denominators.', '**Scale extension.** Table 7 uses the same metric definition on 2,232 scorable tasks from 2,174 snapshots. Training-set size also increases for learned arms.')
a=s.index('Three things move and one does not.'); b=s.index('**What you index moves the gap.**',a)
s=s[:a]+'''The BM25 ratio is similar across scales, **2.27× versus 2.28×**. Graph reranking gains +0.022 on symbols (169 wins, 90 losses; positive in 8 of 12 repositories). Its file effect is +0.000 with CI (−0.009, 0.008), compatible with small positive or negative effects. Graph features add +0.027 inside the learned ranker. The evidence override's Lite gain does not persist at full scale: −0.002. Sample composition and additional training data both change, so this comparison alone cannot identify why.

'''+s[b:]
a=s.index('**How many tasks a claim needs.**'); b=s.index('*Table 8',a)
s=s[:a]+'''**Subsample stability.** We draw 400 subsets without replacement from the fixed 2,232 paired differences at each size and apply the same sign test. The graph effect is detected in 39% of 290-task subsets and 87% of 800-task subsets; the ranker effect in 88% at n = 100. These are dataset-conditional detection frequencies, not prospective power estimates. At n = 2,232 every draw is the full set, making 0 or 1 inevitable.

'''+s[b:]
s=s.replace('share of resamples whose sign test reaches p < 0.05, by sample size','share of subsets whose sign test reaches p < 0.05; full-size column is deterministic')
s=s.replace('**Reproducibility.** Every number is re-derived from the released JSONL by a 265-assertion check: a claim that drifts from the data fails the build, not the review.', '**Reproducibility.** We release per-task rankings, labels, and numerical checks (`tools/audit_numbers.py`), plus commands and fold definitions in `docs/reproduction.md`. Auditing saved outputs is distinct from rerunning retrieval and training.')
section('## 6. Discussion','## 7. Limitations','''## 6. Discussion

The diagnostic separates two interventions. Reranking changes selection inside a pool; expansion can add targets but also displace existing hits. On Lite, an oracle over the 200-candidate lexical pool reaches 0.600, rising to 0.630 with neighbours. These ceilings apply to these candidate sets, not stronger retrievers or different graphs.

The 80 tasks with no gold in the 500-candidate pool show a further limit: our exact-match checks find a gold-body quote in one, a named gold file in one, a traceback naming a patch file in eight, and a symbol name in five; their union is 12 tasks (15%). The other 68 lack these detected cues, not necessarily all useful semantic evidence. The tested dense index over all definitions leaves Lite task-hit coverage at 62.8% after union with lexical retrieval. This is evidence about that encoder and indexing policy, not semantic retrieval in general.

Graph and issue evidence are complementary: graph features help at scale, while index bodies and dense scoring produce larger gains in these experiments. A factorial comparison of graph utility across stronger body-aware and dense rankings would test whether the graph result survives changes to the retrieval baseline.''')
section('## 7. Limitations','## 8. Conclusion','''## 7. Limitations

Python only; one heuristic static graph; no equal-token comparison or downstream repair evaluation. The eight-arm study uses metadata BM25, while only graph reranking is repeated at full scale. Multi-turn graph navigation and type-aware graphs are outside scope. Reference-patch symbols are one repair's targets, not all valid solutions; new definitions and module-level changes require different metrics. Issue-evidence buckets use gold for retrospective analysis, not deployable routing. Lite is nested in the full split; method development reused this benchmark. Task-level intervals and sign tests do not fully model repository dependence or multiple comparisons. We claim empirical diagnostics, not a universal graph limit or a new localization algorithm.''')
section('## 8. Conclusion','## References','''## 8. Conclusion

Fixed-slot retrieval can credit a file hit while missing the edited definition. Our audit attributes failures to candidate coverage and shortlist displacement: simple graph expansion is weak under this setup, while graph reranking yields a small positive effect at scale. Including body text changes the measured gap; combining explicit features with dense scores reaches 44.7% symbol and 72.7% file recall. The contribution is a reproducible account of these conditional effects and their limits.''')
s=s.replace('[10] FuseSearch: Learning Adaptive Parallel Execution for Efficient Code Localization. ACL 2026 Findings.', '[10] FuseSearch: Learning Adaptive Parallel Execution for Efficient Code Localization. ACL 2026 Findings.\n[11] Saurav Bellam. How Do Small Coding Agents Use Code Graphs and Embeddings? arXiv:2610.33958, 2026.')
s=s.replace('at ten slots no graph arm improves symbol recall (8 arms)', 'no significant symbol improvement among seven graph variants on Lite at ten slots')
s=s.replace('+2.2 points needs n ≈ 800 (39% power at 290); +11.3 is seen at n = 100 in 88%', 'conditional subset detection: graph 39% at 290 / 87% at 800; ranker 88% at 100')
s=s.replace('a dense index over the whole repository rescues none of the 27.6% tail: union 62.8% = BM25\'s rate, oracle flat','the tested whole-repository dense index leaves union task coverage at 62.8%')
s=re.sub(r'## (\d\. [^\n]+) \(\d+ words\)',r'## \1',s)
s=s.replace('**≤ 3,000 words** (counted with `tools/make_submission.py`: 2,997 as Kaggle counts it)', '**≤ 3,000 words** (recount with `tools/make_submission.py` after each edit)')
s=s.replace('every number traceable to `data/*.jsonl` via `tools/audit_numbers.py` (265 assertions)', 'numerical claims checked against saved outputs by `tools/audit_numbers.py`')
p.write_text(s,encoding='utf-8',newline='\n')
# The paper now uses this model; keep the runnable default and documentation aligned.
p=Path('tools/embed_retrieve.py'); s=p.read_text(encoding='utf-8'); a=s.index('"""'); b=s.index('"""',a+3)
s='''"""Frozen bge-small-en-v1.5 cosine scores over the shared candidate pool.

Reproduce the paper with --model models/bge-small-en-v1.5. Inputs include the
candidate body (first 800 characters), so this is not an equal-input comparison
with metadata-only BM25. The issue uses its first 1,200 characters; both inputs
are capped at 512 tokens. No fine-tuning is performed.
"""'''+s[b+3:]; s=s.replace('"models" / "jina-code"','"models" / "bge-small-en-v1.5"'); p.write_text(s,encoding='utf-8',newline='\n')
# Update conversion legends for the inserted full-scale table.
p=Path('tools/make_kaggle_full.py'); s=p.read_text(encoding='utf-8'); s=s.replace('6: "each row: n · BM25 · ranker, for 290 tasks then 2,232",\n    7: "reading: 290 tasks · 2,232 tasks",','6: "ranking: symbol recall@10 · file recall@10",\n    7: "each row: n · BM25 · ranker, for 290 tasks then 2,232",\n    8: "reading: 290 tasks · 2,232 tasks",'); p.write_text(s,encoding='utf-8',newline='\n')
p=Path('.gitignore'); s=p.read_text(encoding='utf-8'); s+='\n# Local build caches and publication review intermediates.\n.cache/\ntmp/\n'; p.write_text(s,encoding='utf-8',newline='\n')
