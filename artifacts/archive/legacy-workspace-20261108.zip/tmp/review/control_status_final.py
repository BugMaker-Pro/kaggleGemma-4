﻿from pathlib import Path
p=Path('docs/status.md');s=p.read_text(encoding='utf-8');s=s.replace('2,457 词','2,451 词').replace('**2,928 词**','**2,922 词**').replace('预留 72','预留 78').replace('2,904 词','2,898 词').replace('submission.pdf)，5 页','submission.pdf)，6 页（参考文献独立一页）');p.write_text(s,encoding='utf-8',newline='\n')
