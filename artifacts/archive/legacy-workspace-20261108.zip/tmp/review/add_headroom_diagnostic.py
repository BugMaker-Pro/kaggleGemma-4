﻿from pathlib import Path
p=Path('tools/analyse_graph_controls.py');s=p.read_text(encoding='utf-8')
needle="def fmt_effect(stats):"
addition='''def retained_seed_diagnostics(path, wanted):
    # Descriptive headroom only; not an additional significance test or a
    # selection criterion. It guards against calling seed saturation causal.
    collected={rep:defaultdict(list) for rep in REPRESENTATIONS}
    with Path(path).open(encoding='utf-8') as handle:
        for line in handle:
            if not line.strip():
                continue
            context=json.loads(line)
            if context['instance_id'] not in wanted:
                continue
            labels=context['labels'];total=context['gold_total'];pool_hits=sum(labels)
            for rep,order in context['orders'].items():
                seed_hits=sum(labels[i] for i in order[:5])
                base_hits=sum(labels[i] for i in order[:10])
                oracle=seed_hits+min(5,pool_hits-seed_hits)
                collected[rep]['seed_recall'].append(seed_hits/total)
                collected[rep]['remaining_slot_oracle'].append(oracle/total)
                collected[rep]['available_recall_gain'].append((oracle-base_hits)/total)
                collected[rep]['tasks_with_reordering_headroom'].append(int(oracle>base_hits))
    return {rep:{metric:(sum(values) if metric.startswith('tasks_') else statistics.fmean(values))
                 for metric,values in metrics.items()} for rep,metrics in collected.items()}


'''
s=s.replace(needle,addition+needle)
needle="    lines+=['','## 预先指定的五个主要对比','',"
replacement="""    if 'retained_seed_diagnostics' in summary:
        lines+=['','### 保留种子的剩余改善空间（事后描述，非新增检验）','',
                '| 表示 | 前五种子金标 recall | 保留种子后的 oracle@10 | 相对原排序最大可改善空间 | 仍可通过重排改善的任务 |',
                '| --- | ---: | ---: | ---: | ---: |']
        for rep,diag in summary['retained_seed_diagnostics'].items():
            lines.append(f"| {rep} | {diag['seed_recall']:.4f} | {diag['remaining_slot_oracle']:.4f} | {diag['available_recall_gain']:.4f} | {diag['tasks_with_reordering_headroom']} |")
        lines+=['','表示更强时，种子可能已包含更多答案；交互效应也可能受剩余改善空间影响。不能将交互直接归因为正文补偿了图信息。']
    lines+=['','## 预先指定的五个主要对比','',"""
assert needle in s;s=s.replace(needle,replacement)
needle="    lite=[row for row in rows if row['instance_id'] in lite_ids]"
s=s.replace(needle,"    context_path=Path(args.rows).with_name(Path(args.rows).stem+'_context.jsonl')\n    summary['context_sha256']=sha(context_path)\n    summary['retained_seed_diagnostics']=retained_seed_diagnostics(context_path,set(ids))\n"+needle)
p.write_text(s,encoding='utf-8',newline='\n')
