﻿from pathlib import Path
p=Path('tools/make_thumbnail.py');s=p.read_text(encoding='utf-8');s=s.replace('and what arrives is 16× the code the fix touches: 29 KB to find 1.7 KB', 'gold files contain 16× the source text of the touched definitions');s=s.replace('300 SWE-bench Lite tasks, re-checked on 2,232 · 8 graph arms add 2 points', '290 scorable Lite tasks · graph reranking gains 2.2 points on 2,232');s=s.replace('a ranker reaches 33–36% of symbols; 85% of what the pool misses is never named', 'a ranker plus a dense score reaches 44.7% of symbols on the full split');p.write_text(s,encoding='utf-8',newline='\n')
# Normalize new text files to the repository's UTF-8 without BOM / LF convention.
for name in ['README.md','paper/kaggle_body.md','docs/reproduction.md','docs/novelty-review.md','tools/check_publication.py']:
 p=Path(name);s=p.read_text(encoding='utf-8-sig');p.write_text(s,encoding='utf-8',newline='\n')
