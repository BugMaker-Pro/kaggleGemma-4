﻿from pathlib import Path
p=Path('docs/novelty-review.md');s=p.read_text(encoding='utf-8');anchor='## 判断\n';s=s.replace(anchor,'''## 后续状态：实验已完成

2026-11-01 已按下述方向完成全部 2,232 个任务的固定候选池实验。真实图相对主随机对照在 metadata/dense 下有正收益，但表示交互未通过 Holm 校正；这不支持“强文本让图无用”的预设故事。完整结果见 [graph-control-results.md](graph-control-results.md)，研究判断与审计差异见 [graph-control-interpretation.md](graph-control-interpretation.md)。以下“下一步”章节保留为实验前的设计记录，不代表尚未执行。

## 判断
''');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('README.md');s=p.read_text(encoding='utf-8');s=s.replace('## Recompute the reported metrics', '''## Topology-control follow-up (November 1)

All 2,232 tasks now have a fixed-pool, seed-retaining comparison across metadata,
body BM25, and frozen dense ranking. Real graphs beat degree/file-constrained
rewiring by 2.14 / 0.90 / 1.76 points; metadata and dense contrasts survive the
five-test Holm correction. Gains over each original ranking are 2.19 / -0.01 /
0.64 points. The representation interactions do not survive correction.

This distinguishes topology carrying information from a simple reranking policy
improving retrieval. It does not show that stronger text makes graphs redundant.
Historical Lite seed handling and dense rounding ties differ; both are disclosed.

[Results and figure](docs/graph-control-results.md) ·
[Frozen protocol](docs/graph-control-protocol.md) ·
[Interpretation](docs/graph-control-interpretation.md) ·
[Reproduce](docs/graph-control-reproduction.md)

```bash
uv run python tools/audit_graph_controls.py
uv run python tools/analyse_graph_controls.py
```

## Recompute the reported metrics''')
s=s.replace('and the experiments still needed to distinguish topology effects from file proximity and weak text representations.', 'and the completed follow-up distinguishing topology signal from intervention value under stronger representations.')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/status.md');s=p.read_text(encoding='utf-8');s=s.replace('2,321 词','2,457 词').replace('**10 个图片位**','**9 个图片位**').replace('`table_resolution` → ','').replace('**2,842 词**','**2,928 词**').replace('预留 158','预留 72').replace('2,806 词','2,904 词')
s=s.replace('表格图共有 9 张（状态表 + Table 1–8）。另有 Figure 1，共 10 个图片位。', '表格图共有 8 张（Table 1–8）。另有 Figure 1，共 9 个图片位；旧 `table_resolution.png` 不再使用。')
s=s.replace('旧 Table 5–7 顺延。', 'Table 8 已替换为全量拓扑对照，原样本量结果保留在补充记录。')
s=s.replace('## 状态\n','''## 状态

- [x] **拓扑控制实验完成**：2,232/2,232；三种表示、两类匹配随机图、同文件控制；输入哈希固定；734,354 项独立审计检查零失败。见 [结果](graph-control-results.md) 与 [解释](graph-control-interpretation.md)。
- [x] dense 历史并列处理敏感性：一个任务的基线 recall 改变，五项主要推断不变。
- [x] 投稿摘要/方法/结果/讨论已纳入新实验；强调结构信号与具体干预净收益的区别，交互不显著。
''');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/reproduction.md');s=p.read_text(encoding='utf-8');s=s.replace('The November 1 revision changes reporting and build consistency; it does not retrain models or replace experiment outputs.', 'The initial November 1 revision changed reporting and build consistency. A later topology-control follow-up adds new experiment outputs without retraining models or replacing historical outputs; see `graph-control-reproduction.md`.');p.write_text(s,encoding='utf-8',newline='\n')
