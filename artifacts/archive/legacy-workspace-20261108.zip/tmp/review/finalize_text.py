﻿from pathlib import Path
p=Path('paper/main.md');s=p.read_text(encoding='utf-8');s=s.replace('slots 6?10; score fusion with ? = 0.5', 'slots 6-10; score fusion with lambda = 0.5')
a=s.index('**Source size, not measured agent cost.**');b=s.index('\n\n',a)
s=s[:a]+"**Source size.** Median gold-file and touched-definition lengths are 28,950 and 1,726 characters; 112 tasks exceed a 25× ratio. These lengths do not establish token, latency, or repair savings."+s[b:]
a=s.index('**Where the gap is.**');b=s.index('\n\n',a)
s=s[:a]+"**Within-file selection.** Given oracle gold files, ten slots recover **66.5%** of gold symbols."+s[b:]
s=s.replace('This is repository-held-out two-fold evaluation, not a new ranking algorithm.', 'This is repository-held-out two-fold evaluation.')
s=s.replace('| best graph arm, symbol |', '| graph rerank, symbol |').replace('| best graph arm, file |', '| graph rerank, file |')
s=s.replace('the best graph arm is +0.022 symbol, +0.000 file at 2,232', 'graph reranking is +0.022 symbol, +0.000 file at 2,232')
s=s.replace('not previously published (Non-Archival permits posting only after submission)', 'original and unpublished at submission; check the current official publication policy')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/papers/notes.md');s=p.read_text(encoding='utf-8');s=s.split('\n## 11. Bellam:')[0]+'''
## 11. Bellam: How Do Small Coding Agents Use Code Graphs and Embeddings? (2026)

核实日期：2026-11-01。官方摘要 https://arxiv.org/abs/2610.33958 与全文 https://arxiv.org/html/2610.33958v1。作者 Saurav Bellam，v1 提交日期 2026-10-25，均从 arXiv citation metadata 核对。

直接相关：grep、embedding、graph 工具组合的消融，按图距离分层，多种小模型（包括 Gemma 4），以及固定修复模型的下游验证。正文讨论图工具收益来自名称查找和短程扩展。这与本稿图的边际价值和字面证据明显重叠，不能忽略或声称首次。

本稿引用用于定位研究范围：该文研究多轮 agent 工具使用；本稿研究固定槽位静态排序中的候选覆盖、金标替换及索引正文干预。两者不是可直接比较的性能基线。详细新颖性评估和待做实验见 `docs/novelty-review.md`。
''';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tools/make_submission.py');s=p.read_text(encoding='utf-8');s=s.replace('words as Kaggle will count them:', 'word estimate (repository counter):');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tools/check_publication.py');s=p.read_text(encoding='utf-8');s=s.replace('    for phrase in ["equal character budget",', '    for phrase in ["6?10", "with ? =", "equal character budget",');p.write_text(s,encoding='utf-8',newline='\n')
